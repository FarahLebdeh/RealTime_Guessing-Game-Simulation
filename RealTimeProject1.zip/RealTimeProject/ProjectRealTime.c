
 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <signal.h>
pid_t pid, pid_array[3];
pid_t pid_arrayP[2];
int flag1, flag2;
int status=0;
int countCh1=0,countCh2=0;
int main()
{
void randomcount1(int signum);
void randomcount2(int signum);
void inform ( int signum);
void exit1 ( int signum);
int i, status;
flag1=0,flag2=0;
  printf("My process ID is %d\n", getpid());
  pid_array[0]=getpid();

  for ( i = 1; i < 3; i++ ) {
    pid = fork();
    
    if ( pid == 0 ) {
      if(i==1){
      sigset(SIGUSR1,randomcount1);
              if (sigset(SIGUSR1,randomcount1) == SIG_ERR)
                {
                    perror("Sigset can not set SIGUSR1");
                    exit(SIGUSR1);
                }
       }else{
       sigset(SIGUSR1,randomcount2);
              if (sigset(SIGUSR1,randomcount2) == SIG_ERR)
                {
                    perror("Sigset can not set SIGUSR1");
                    exit(SIGUSR1);
                }
       }
      while(1);
    }
    else {
     
      printf("I am the parent => PID = %d, child ID = %d\n", getpid(), pid);
      pid_array[i] = pid;
      pid_arrayP[i-1]=getpid();
      if (sigset(SIGINT,inform) == SIG_ERR)
                {
                    perror("Sigset can not set SIGINT");
                    exit(SIGINT);
                }
      if(sigset(SIGQUIT, exit1)== SIG_ERR){
  perror("Sigset can not set SIGQUIT");
  exit(SIGQUIT);
  }
    }
  }
  sleep(1);

  while(countCh1 <10 && countCh2 < 10) {
  if(kill(pid_array[1],SIGUSR1)==0){ // write random number on p1.txt
      flag1=1;
      }
     
  sleep(1);
  if(kill(pid_array[2],SIGUSR1)==0){ // write random number on p2.txt
      flag2=1;
      
      }
  sleep(3);    
  if(kill(pid_array[0] , SIGINT) == 0) { // check if parent informed

    printf("\n");
    } }
  if(countCh1 == 10 && countCh2 != 10) {
  printf("*************Child 1 winner*************\n");
  sleep(1);

  }
  else if(countCh2 == 10 && countCh1 != 10) {
  printf("*************Child 2 winner*************\n");
  sleep(1);
  kill(pid_array[0], SIGQUIT);
 
 
  }
 
  else if(countCh2 == 10 && countCh1 == 10) {
  printf("*************child 1 && child 2 winners*************\n");
  sleep(1);
 kill(pid_array[0], SIGQUIT);
 
 
  }
  return(0);
}
//////////////////////////////////////////////////////////
void randomcount1(int signum) {
srand(time(NULL)%getpid());
flag1=1;
printf("Child 1 started counting randomly\n");;
FILE *f1=fopen("p1.txt","w");
int r1 = rand()%100+1;
fprintf(f1,"%d",r1);
fclose(f1);
}
///////////////////////////////////////////////////////////
void randomcount2(int signum) {
srand(time(NULL)%getpid());
flag2=1;
printf("Child 2 started counting randomly\n");
FILE *f2=fopen("p2.txt","w");
int r2 = rand()%100+1;
fprintf(f2,"%d",r2);
fclose(f2);

}
//////////////////////////////////////////////////////////
void inform ( int signum) {
sleep(3);
if(flag1==1 && flag2==1){
  printf("PARENT INFORMED #1 , PARENT INFORMED #2\n");
  FILE *f1=fopen("p1.txt","r");
  FILE *f2=fopen("p2.txt","r");
  int num1,num2;
  fscanf(f1,"%d",&num1);
  fscanf(f2,"%d",&num2);
  sleep(1);
  if(num1>num2){
  countCh1++;
  printf("num1 is greater\n");
  }else if(num1<num2){
  countCh2++;
  printf("num2 is greater\n");
  }else{
  countCh1++;
  countCh2++;
  printf("Equals \n");
 
  }
  printf("counter 1 is %d , counter 2 is %d ", countCh1, countCh2);
  remove("p1.txt");
  remove("p2.txt");
 
  }else if(flag1==0 && flag2==1){
  printf("PARENT NOT INFORMED #1 , PARENT INFORMED #2\n");
  }else if(flag1==1 && flag2==0){
  printf("PARENT INFORMED #1 , PARENT NOT INFORMED #2\n");
  }else{
  printf("PARENT NOT INFORMED #1 , PARENT NOT INFORMED #2\n");
  }
 
 
}

void exit1(int signum){
exit(SIGQUIT);

}

